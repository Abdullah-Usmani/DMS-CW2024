package com.example.demo;

public class Config {
    private static int screenWidth = 800; // Default width
    private static int screenHeight = 600; // Default height

    public static int getScreenWidth() {
        return screenWidth;
    }

    public static void setScreenWidth(int width) {
        screenWidth = width;
    }

    public static int getScreenHeight() {
        return screenHeight;
    }

    public static void setScreenHeight(int height) {
        screenHeight = height;
    }
}