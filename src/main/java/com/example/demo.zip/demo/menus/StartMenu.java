package com.example.demo.menus;

import com.example.demo.Config;
import com.example.demo.controller.Controller;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class StartMenu {

    private final Stage stage;

    public StartMenu(Stage stage) {
        this.stage = stage;
    }

    public Scene initializeMenu() {
        // Create menu buttons
        Button startGameButton = new Button("Start Game");
        Button settingsButton = new Button("Settings");
        Button helpButton = new Button("Help");
        Button exitButton = new Button("Exit");

        // Set button actions
        startGameButton.setOnAction(e -> startGame());
        settingsButton.setOnAction(e -> openSettings());
        helpButton.setOnAction(e -> openHelp());
        exitButton.setOnAction(e -> System.exit(0));

        // Arrange buttons in a vertical layout
        VBox menuLayout = new VBox(20, startGameButton, settingsButton, helpButton, exitButton);
        menuLayout.setStyle("-fx-alignment: center; -fx-padding: 20;");

        // Create and return the scene
        return new Scene(menuLayout, Config.getScreenWidth(), Config.getScreenHeight());
    }

    private void openSettings() {
        SettingsMenu settingsMenu = new SettingsMenu(stage);
        Scene settingsScene = settingsMenu.initializeMenu();
        stage.setScene(settingsScene);
    }

    private void openHelp() {
        HelpMenu helpMenu = new HelpMenu(stage);
        Scene helpScene = helpMenu.initializeMenu();
        stage.setScene(helpScene);
    }

    private void startGame() {
        System.out.println("Starting the game...");
        Controller controller = new Controller(stage);
        controller.launchGame();
    }

    private void exitGame() {
        System.out.println("Exiting the game...");
        System.exit(0);
    }
}
