package com.example.demo.menus;

import com.example.demo.Config;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class HelpMenu {

    private final Stage stage;

    public HelpMenu(Stage stage) {
        this.stage = stage;
    }

    public Scene initializeMenu() {
        // Back to start menu
        Button backButton = new Button("Back to Start Menu");
        backButton.setOnAction(e -> goToStartMenu());

        // Arrange controls in a vertical layout
        VBox layout = new VBox(20, backButton);
        layout.setStyle("-fx-alignment: center; -fx-padding: 20;");

        return new Scene(layout, Config.getScreenWidth(), Config.getScreenHeight());
    }

    private void goToStartMenu() {
        StartMenu startMenu = new StartMenu(stage);
        Scene menuScene = startMenu.initializeMenu();
        stage.setScene(menuScene);
    }
}
